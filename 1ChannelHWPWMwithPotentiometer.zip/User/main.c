/*
 * Project: Potentiometer-Controlled PWM
 * MCU: CH32V003J4M6
 * Description: This program generates a 1kHz Hardware PWM signal on PC4 (TIM1 Channel 4),
 *              with Duty Cycle controlled by a 10k potentiometer connected to PA1 (ADC Channel 1).
 *              System Clock is set to 48MHz using HSI/2 * 12.
 *              ADC uses 241-cycle sampling for high accuracy.
 * Author: [Your Name or Anonymous]
 * Date: May 2025
 */

#include "ch32v00x.h"

// Function Prototypes
void System_Clock_Config(void);
void GPIO_Config(void);
void ADC_Config(void);
void TIM1_PWM_Config(void);
uint16_t ADC_Read(uint8_t channel);

// Configure System Clock to 48MHz using HSI
void System_Clock_Config(void) {
    RCC_DeInit();
    RCC_HSICmd(ENABLE);
    while(RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET);

    // Configure PLL: HSI/2 * 12 = 48MHz
    RCC->CFGR0 &= ~(1 << 16 | 0xF << 18); // Clear PLLSRC (bit 16) and PLLMUL (bits 18-21)
    RCC->CFGR0 |= (0 << 16) | (0xA << 18); // PLLSRC = HSI/2, PLLMUL = x12
    RCC_PLLCmd(ENABLE);
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);

    // Set Flash Latency for 48MHz
    FLASH->ACTLR &= ~FLASH_ACTLR_LATENCY;
    FLASH->ACTLR |= FLASH_ACTLR_LATENCY_1;

    // Select PLL as System Clock
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    while(RCC_GetSYSCLKSource() != 0x08); // Wait for PLLCLK

    RCC_HCLKConfig(RCC_SYSCLK_Div1); // HCLK = SYSCLK / 1
    SystemCoreClockUpdate();
}

// Configure GPIO: PA1 as ADC input, PC4 as PWM output
void GPIO_Config(void) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);

    GPIO_InitTypeDef GPIO_InitStructure = {0};

    // PA1: Analog Input for ADC (Potentiometer)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // PC4: Alternate Function Push-Pull for PWM (TIM1 CH4)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
}

// Configure ADC for PA1 (Channel 1)
void ADC_Config(void) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

    ADC_InitTypeDef ADC_InitStructure = {0};
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &ADC_InitStructure);

    // Configure ADC Channel 1 (PA1)
    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_241Cycles);

    // Enable ADC
    ADC_Cmd(ADC1, ENABLE);

    // Calibrate ADC
    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));

    // Start ADC Conversion
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}

// Read ADC value from specified channel
uint16_t ADC_Read(uint8_t channel) {
    ADC_RegularChannelConfig(ADC1, channel, 1, ADC_SampleTime_241Cycles);
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
    return ADC_GetConversionValue(ADC1);
}

// Configure Timer1 for Hardware PWM on PC4 (Channel 4)
void TIM1_PWM_Config(void) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure = {0};
    TIM_OCInitTypeDef TIM_OCInitStructure = {0};

    // Timer1 Base Configuration (1kHz PWM)
    TIM_TimeBaseStructure.TIM_Period = 999; // PWM Resolution: 1000 steps
    TIM_TimeBaseStructure.TIM_Prescaler = 47; // 48MHz / (47 + 1) = 1MHz
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

    // PWM Channel 4 Configuration (PC4)
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 500; // Initial Duty Cycle 50%
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC4Init(TIM1, &TIM_OCInitStructure);

    // Enable Preload and Timer
    TIM_OC4PreloadConfig(TIM1, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM1, ENABLE);
    TIM_Cmd(TIM1, ENABLE);

    // Enable PWM output
    TIM_CtrlPWMOutputs(TIM1, ENABLE);
}

int main(void) {
    System_Clock_Config();
    GPIO_Config();
    ADC_Config();
    TIM1_PWM_Config();

    uint16_t adc_value;
    while(1) {
        // Read ADC value from PA1 (Channel 1)
        adc_value = ADC_Read(ADC_Channel_1);

        // Map ADC value (0-1023) to PWM Duty Cycle (0-999)
        uint16_t duty_cycle = 1024-(uint32_t)adc_value * 1000 / 1024;

        // Update PWM Duty Cycle
        TIM_SetCompare4(TIM1, duty_cycle);
    }
}
